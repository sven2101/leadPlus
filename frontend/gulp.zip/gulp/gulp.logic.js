/**
 * Created by Max on 08.05.2016.
 */

module.exports = {
    logic: {}
};